from rest_framework import viewsets
from .models import Usuario, Vehicle
from django.http.response import JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from uuid import uuid4
from .serializer import UsuarioSerializer
from rest_framework import viewsets
import json
# Create your views here.

class UsuarioSearchView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    def post(self, request, token=""):
        jd = json.loads(request.body)
        usuarios = list(Usuario.objects.filter(token_user=token).values())
        if len(usuarios) > 0:
            try:
                if Usuario.objects.get(token_user='84a1c466-11c4-4af6-b30a-2a547d400fd0'):
                    usersearch = list(Usuario.objects.filter(email=jd['email']).values())
                    datos = {'uservalue': usersearch}
            except:
                datos = {'message': "uservalue not found..."}
        else:
            datos = {'message': "uservalue not found..."}
        return JsonResponse(datos)

class UsuarioLoginView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    def post(self, request):
        jd = json.loads(request.body)
        usuarios = list(Usuario.objects.values())
        if len(usuarios) > 0:
            if (jd['email']=='admin@example.com' and jd['password']=='123123123'):
                usuarios = list(Usuario.objects.filter(email=jd['email']).values())
                uservalue = usuarios[0]['token_user']
                datos = {'uservalue': 'admin', 'tokenadmin': uservalue}
            else:
                try:
                    if (Usuario.objects.get(email=jd['email']) and Usuario.objects.get(password=jd['password'])):
                        uservalue = usuarios[0]['token_user']
                        datos = {'message': 'token', 'uservalue': uservalue}
                except:
                    datos = {'message': "Bad credentials"}
        else:
            datos = {'message': "uservalue not found..."}
        return JsonResponse(datos)

class UsuarioView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request, token=""):
        usuarios = list(Usuario.objects.filter(token_user=token).values())
        if len(usuarios) > 0:
            uservalue = usuarios[0]
            datos = {'message': "Success", 'uservalue': uservalue}
        else:
            datos = {'message': "uservalue not found..."}
        return JsonResponse(datos)

    def post(self, request):
        # print(request.body)
        jd = json.loads(request.body)
        # print(jd)
        Usuario.objects.create(email=jd['email'], id_card=jd['id_card'], phone=jd['phone'], password=jd['password'], token_user=str(uuid4()))
        datos = {'message': "Success"}
        return JsonResponse(datos)

    def put(self, request, token):
        jd = json.loads(request.body)
        userList = list(Usuario.objects.filter(token_user=token).values())
        if len(userList) > 0:
            usuarios = Usuario.objects.get(token_user=token)
            usuarios.email = jd['email']
            usuarios.id_card = jd['id_card']
            usuarios.phone = jd['phone']
            usuarios.password = jd['password']
            usuarios.save()
            datos = {'message': "Success"}
        else:
            datos = {'message': "Usuario not found..."}
        return JsonResponse(datos)

    def delete(self, request, token):
        userList = list(Usuario.objects.filter(token_user=token).values())
        if len(userList) > 0:
            Usuario.objects.filter(token_user=token).delete()
            datos = {'message': "Success"}
        else:
            datos = {'message': "Usuario not found..."}
        return JsonResponse(datos)

class VehicleSearchView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    def post(self, request, token, placa):
        usuarios = list(Usuario.objects.filter(token_user=token).values())
        if len(usuarios) > 0:
            instanceUser = Usuario.objects.get(token_user=token)
            vehicleupdate = list((Vehicle.objects.filter(placa=placa).values()))
            if len(vehicleupdate) > 0:
                datos = {'uservalue': vehicleupdate}
            else:
                datos = {'message': "Error no vehicle"}
        else:
            datos = {'message': "Error no users"}
        return JsonResponse(datos)


class VehicleView(View):
    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def post(self, request, token):
        userList = list(Usuario.objects.filter(token_user=token).values())
        if len(userList) > 0:
            instanceUser = Usuario.objects.get(token_user=token)
            jd = json.loads(request.body)
            Vehicle.objects.create(placa=jd['placa'], vehiculo=jd['vehiculo'], tipo_arreglo=jd['tipo_arreglo'], description=jd['description'], mecanico=jd['mecanico'], userfk=instanceUser)
            datos = {'message': "Success"}
            return JsonResponse(datos)

    def get(self, request, token=""):
        usuarios = list(Usuario.objects.filter(token_user=token).values())
        if len(usuarios) > 0:
            instanceUser = Usuario.objects.get(token_user=token)
            vehicle = list(Vehicle.objects.filter(userfk=instanceUser).values())
            if len(vehicle) > 0:
                datos = {'uservalue': vehicle}
            else:
                datos = {'message': "Error no vehicle"}
        else:
            datos = {'message': "Error no users"}
        return JsonResponse(datos)

    def put(self, request, token, placa):
        jd = json.loads(request.body)
        userList = list(Usuario.objects.filter(token_user=token).values())
        if len(userList) > 0:

            instanceUser = Usuario.objects.get(token_user=token)
            try:
                vehicleupdate = Vehicle.objects.filter(userfk=instanceUser).get(placa=placa)
                vehicleupdate.placa = jd['placa']
                vehicleupdate.vehiculo = jd['vehiculo']
                vehicleupdate.tipo_arreglo = jd['tipo_arreglo']
                vehicleupdate.description = jd['description']
                vehicleupdate.mecanico = jd['mecanico']
                vehicleupdate.save()
                datos = {'message': "Success"}
            except:
                datos = {'message': "Error no vehicle"}
        else:
            datos = {'message': "Usuario not found..."}
        return JsonResponse(datos)

    def delete(self, request, token, placa):
        userList = list(Usuario.objects.filter(token_user=token).values())
        if len(userList) > 0:
            instanceUser = Usuario.objects.get(token_user=token)
            try:
                vehicleupdate = Vehicle.objects.filter(userfk=instanceUser).get(placa=placa).delete()
                datos = {'message': "Success"}
            except:
                datos = {'message': "Error no vehicle"}
        else:
            datos = {'message': "Usuario not found..."}
        return JsonResponse(datos)