<?php
// Verificar si el usuario ha iniciado sesión; si no, redirigir al inicio de sesión
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.html"); 
    exit;
}

// Obtener la información del taller mecánico desde la base de datos (sustituye con tus nombres de tabla)
$servername = "localhost";
$username = "tu_usuario";
$password = "tu_contraseña";
$dbname = "nombre_de_la_base_de_datos";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

$username = $_SESSION['username']; // El nombre de usuario se almacena en la sesión

// Consulta para obtener la información del taller para el usuario en sesión
$sql = "SELECT * FROM taller WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    // Mostrar los detalles del taller
    $row = $result->fetch_assoc();
    echo "<h1>Bienvenido al Taller Mecánico " . $row['nombre'] . "</h1>";
    echo "<p>Dirección: " . $row['direccion'] . "</p>";
    echo "<p>Tipo de Trabajo: " . $row['tipo_trabajo'] . "</p>";
    echo "<p>Fecha de Entrega Máxima: " . $row['fecha_entrega'] . "</p>";
} else {
    echo "No se encontró información del taller.";
}

$conn->close();
?>
